import 'package:flutter/material.dart';


/// Our Color Palette Here
Color darkColor = Color(0xff433F67);
Color pinkishColor = Color(0xffFF3366);
Color yellowishColor = Color(0xffF6CA14);
Color bgColor = Color(0xffF9F9F9);
Color whitishColor = Color(0xffffffff);