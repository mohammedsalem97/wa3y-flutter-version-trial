import 'package:flutter/widgets.dart';
//Wa3yIcons
class Wa3yIcons {
  Wa3yIcons._();

  // Generated code: do not hand-edit.
  // See https://github.com/flutter/flutter/wiki/Updating-Material-Design-Fonts
  // BEGIN GENERATED

  /// analysis
  static const IconData analysis = IconData(0xe900, fontFamily: 'Wa3yIcons');//
  /// back_again
  static const IconData back_again = IconData(0xe91f, fontFamily: 'Wa3yIcons');
//  /// qAndA
//  static const IconData qAndA = IconData(0xe927, fontFamily: 'Wa3yIcons');//
//  /// analysis
//  static const IconData analysis = IconData(0xe900, fontFamily: 'Wa3yIcons');
//  /// analysis
//  static const IconData analysis = IconData(0xe900, fontFamily: 'Wa3yIcons');
//  /// analysis
//  static const IconData analysis = IconData(0xe900, fontFamily: 'Wa3yIcons');
//  /// analysis
//  static const IconData analysis = IconData(0xe900, fontFamily: 'Wa3yIcons');
//  /// analysis
//  static const IconData analysis = IconData(0xe900, fontFamily: 'Wa3yIcons');
//  /// analysis
//  static const IconData analysis = IconData(0xe900, fontFamily: 'Wa3yIcons');
//  /// analysis
//  static const IconData analysis = IconData(0xe900, fontFamily: 'Wa3yIcons');

}